package models;

import utils.Utils;

import java.time.LocalDateTime;

public class User {

    private int code;
    private String name;
    private boolean isAdmin;
    private LocalDateTime entryDate;
    private boolean entering;

    //Constructor Base para traerse Usuarios:
    public User(int code, String name, boolean isAdmin, boolean entering) {
        this.code = code;
        this.name = name;
        this.isAdmin = isAdmin;
        entryDate = null;
        this.entering = entering;
    }

    //Constructor Base para traerse Registros:
    public User(int code, String name, boolean isAdmin, LocalDateTime entryDate, boolean entering) {
        this.code = code;
        this.name = name;
        this.isAdmin = isAdmin;
        this.entryDate = entryDate;
        this.entering = entering;
    }

    //Constructor Copia para hacer nuevos Registros:
    public User(User user) {
        this.code = user.code;
        this.name = user.name;
        this.isAdmin = user.isAdmin;
        this.entryDate = LocalDateTime.now();
        this.entering = user.entering;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    public void setAdmin(boolean admin) {
        isAdmin = admin;
    }

    public LocalDateTime getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(LocalDateTime entryDate) {
        this.entryDate = entryDate;
    }

    public boolean isEntering() {
        return entering;
    }

    public void setEntering(boolean entering) {
        this.entering = entering;
    }

    @Override
    public String toString() {
        return  name + " - " + code + " - " + ((isEntering())? "Entrada" : "Salida") +
                " - " + Utils.formatearFecha(entryDate) +
                " - " + entryDate.toString().substring(11);
    }
}
