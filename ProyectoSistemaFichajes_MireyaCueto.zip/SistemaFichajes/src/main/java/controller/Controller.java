package controller;

import DAO.DAOManager;
import DAO.DAOuser;
import DAO.DAOuserSQL;
import models.User;

import java.io.Serializable;
import java.util.ArrayList;

public class Controller implements Serializable {

    private ArrayList<User> users;
    private ArrayList<User> signings;
    private DAOManager dao;
    private DAOuserSQL daoUserSQL;

    public Controller() {
        dao = DAOManager.getSinglentonInstance();
        daoUserSQL = new DAOuserSQL();
        this.users = daoUserSQL.readAllUsers(dao, daoUserSQL);
        this.signings = daoUserSQL.readAllSignings(dao, daoUserSQL);
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    public ArrayList<User> getSignings() {
        return signings;
    }

    public void setSignings(ArrayList<User> signings) {
        this.signings = signings;
    }

    public User searchUserByCode(int code) {
        if (!users.isEmpty()){
            for (User user : users){
                if (user.getCode()==code) return user;
            }
        }
        return null;
    }

    //Funciones que permiten interactuar con la BBDD:
    public boolean insertSigning(User user){ return daoUserSQL.insertSigning(user, dao);}
    public boolean updateUser(User user){ return daoUserSQL.updateUser(user, dao);}

}
