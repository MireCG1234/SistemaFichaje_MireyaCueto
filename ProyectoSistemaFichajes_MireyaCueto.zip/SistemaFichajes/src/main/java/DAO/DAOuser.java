package DAO;
import models.User;

import java.util.ArrayList;

public interface DAOuser {

    public boolean insertSigning(User user, DAOManager dao);

    public boolean updateUser(User user, DAOManager dao);

    public ArrayList<User> readAllUsers(DAOManager dao, DAOuserSQL daoUserSQL);

    public ArrayList<User> readAllSignings(DAOManager dao, DAOuserSQL daoUserSQL);

    public User readByCode(int code, DAOManager dao);

}
