package DAO;
import models.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class DAOuserSQL implements DAOuser {

    @Override
    public boolean insertSigning(User user, DAOManager dao) {
        try {
            dao.open();

            //Si quisiera insertar trabajadores/admins desde la app tendría que usar estas sentencias:

            /*String sentencia = "INSERT INTO `USERS` (`CODE`, `NAME`, `ISADMIN`, `LAST_ENTRY_TYPE`) VALUES\n" +
                    "('"+user.getCode()+"', '"+user.getName()+"','"+(user.isAdmin() ? 1 : 0)+"', '"
                    +(user.isEntering() ? 1 : 0)+"')";*/

            /*String sentencia = "INSERT INTO `USERS` (`CODE`, `NAME`, `ISADMIN`, `LAST_ENTRY_TYPE`) VALUES\n" +
                    "('"+user.getCode()+"', '"+user.getName()+"','"+user.isAdmin()+"', '"+user.isEntering()+"')";*/

            //Sentencia para insertar registros a la base de datos:

            String sentencia = "INSERT INTO `SIGNINGS` (`CODE`, `ENTRY_DATE`, `ENTRY_TYPE`) VALUES\n" +
                    "('"+user.getCode()+"', '"+LocalDateTime.now()+"',"+(user.isEntering() ? 1 : 0)+");";

            Statement stmt = dao.getConn().createStatement();
            stmt.executeUpdate(sentencia);

            dao.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return false;
    }

    @Override
    public boolean updateUser(User user, DAOManager dao) {
        try {
            dao.open();

            String sentencia = "UPDATE USERS " +
                    "SET LAST_ENTRY_TYPE = '"+(user.isEntering() ? 1 : 0)+"' " +
                    "WHERE CODE = '"+user.getCode()+"';";

            Statement stmt = dao.getConn().createStatement();
            stmt.executeUpdate(sentencia);

            dao.close();
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    @Override
    public ArrayList<User> readAllUsers(DAOManager dao, DAOuserSQL daoUserSQL) {
        ArrayList<User> lista = new ArrayList<>();
        User user;
        String sentencia;
        sentencia = "select * from USERS";
        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    user = new User(
                            rs.getInt("CODE"),
                            rs.getString("NAME"),
                            rs.getBoolean("ISADMIN"),
                            rs.getBoolean("LAST_ENTRY_TYPE"));
                    lista.add(user);
                }
                dao.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public ArrayList<User> readAllSignings(DAOManager dao, DAOuserSQL daoUserSQL) {
        ArrayList<User> lista = new ArrayList<>();
        User user;
        String sentencia;
        sentencia = "SELECT S.CODE,U.NAME,U.ISADMIN,S.ENTRY_DATE,S.ENTRY_TYPE FROM SIGNINGS S INNER JOIN USERS U ON S.CODE = U.CODE;";
        try {
            dao.open();
            PreparedStatement ps = dao.getConn().prepareStatement(sentencia);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    user = new User(
                            rs.getInt("CODE"),
                            rs.getString("NAME"),
                            rs.getBoolean("ISADMIN"),
                            rs.getTimestamp("ENTRY_DATE").toLocalDateTime(),
                            rs.getBoolean("ENTRY_TYPE"));
                    lista.add(user);
                }
                dao.close();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return lista;
    }

    @Override
    public User readByCode(int code, DAOManager dao) {
        return null;
    }

}
