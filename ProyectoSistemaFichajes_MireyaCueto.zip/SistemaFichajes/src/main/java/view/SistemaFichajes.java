package view;

import controller.Controller;
import models.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.util.Scanner;

public class SistemaFichajes extends JFrame{
    private JPanel panel;
    private JButton boton1;
    private JButton boton2;
    private JButton boton3;
    private JButton boton4;
    private JButton boton5;
    private JButton boton6;
    private JButton boton7;
    private JButton boton8;
    private JButton boton9;
    private JButton boton0;
    private JButton botonBorrar;
    private JButton botonAtras;
    private JButton botonFichar;
    private JLabel etiquetaCodigo;
    private JLabel etiquetaMensaje;
    private JLabel titulo;
    private JPanel panel1;
    private JButton botonPrincipal;
    private JPanel panel2;
    private JList list1;
    private JLabel etiquetaMensajeAdmin;
    private JLabel image;
    private JLabel image2;
    Connection con;

    public static void main(String[] args) {
        SistemaFichajes f = new SistemaFichajes();
        f.setContentPane(new SistemaFichajes().panel);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);
        f.pack();
    }

    private void SetImageLabel (JLabel labelName, String root){
        ImageIcon image = new ImageIcon(root);
        Icon icon = new ImageIcon(
                image.getImage().getScaledInstance(50,50, Image.SCALE_DEFAULT)
        );
        labelName.setIcon(icon);
        this.repaint();
    }

    private void SetImageLabel2 (JLabel labelName, String root){
        ImageIcon image = new ImageIcon(root);
        Icon icon = new ImageIcon(
                image.getImage().getScaledInstance(250,150, Image.SCALE_DEFAULT)
        );
        labelName.setIcon(icon);
        this.repaint();
    }

    public SistemaFichajes() {
        Controller controller = new Controller();
        SetImageLabel(image,"images/logoMipPC.png");
        SetImageLabel2(image2,"images/logoMipPC.png");
        botonFichar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    int code = Integer.parseInt(etiquetaCodigo.getText());
                    //Recupero el usuario con ese código
                    User user = controller.searchUserByCode(code);
                    if (user!=null){
                        //Borro el texto de la Label:
                        etiquetaCodigo.setText("");
                        // Miro si esAdmin o trabajador:
                        if (user.isAdmin()) loginAdmin(controller, panel1, panel2, list1, etiquetaMensajeAdmin);
                        else loginTrabajador(user, controller, etiquetaMensaje, etiquetaCodigo);
                    } else etiquetaMensaje.setText("El código no existe, pruebe de nuevo");
                } catch (Exception exception){
                    etiquetaMensaje.setText("Error en el código insertado");
                }
            }
        });
        boton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "1");
            }
        });
        boton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "2");
            }
        });
        boton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "3");
            }
        });
        boton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "4");
            }
        });
        boton5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "5");
            }
        });
        boton6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "6");
            }
        });
        boton7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "7");
            }
        });
        boton8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "8");
            }
        });
        boton9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "9");
            }
        });
        boton0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (etiquetaCodigo.getText().length() < 4)
                    etiquetaCodigo.setText(etiquetaCodigo.getText() + "0");
            }
        });
        botonBorrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                etiquetaCodigo.setText("");
            }
        });
        botonAtras.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String code = etiquetaCodigo.getText();
                code = code.substring(0,code.length() -1);
                etiquetaCodigo.setText(code);
            }
        });
        botonPrincipal.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                panel2.setVisible(false);
                panel1.setVisible(true);
                etiquetaMensajeAdmin.setText("");
                etiquetaMensaje.setText("");
            }
        });
    }

    //Acciones del Admin:
    private static void loginAdmin(Controller controller, JPanel panel1, JPanel panel2, JList list1, JLabel etiquetaMensajeAdmin) {
        //Creo variables del modelo para rellenar la lista:
        DefaultListModel modelo = new DefaultListModel();
        list1.setModel(modelo);

        //Hago visible el panel del admin
        panel1.setVisible(false);
        panel2.setVisible(true);

        //Muestro la lista de todos los registros del controlador
        if (!controller.getSignings().isEmpty()){
            modelo.removeAllElements();
            for (User signing : controller.getSignings().reversed()){
                modelo.addElement(signing);
                //System.out.println(signing);
            }
        } else etiquetaMensajeAdmin.setText("No hay registros aún.");

    }

    //Acciones del Trabajador:
    private static void loginTrabajador(User user, Controller controller, JLabel etiquetaMensaje, JLabel etiquetaCodigo) {
        // Miro su atributo "entering" para hablarle.
        if (user.isEntering()) etiquetaMensaje.setText("¡Bienvenid@!");
        else etiquetaMensaje.setText("¡Hasta la próxima!");

        //Hago una copia del usuario y lo guardo en registros de la bbdd con la fecha actual
        controller.insertSigning(user);

        //Hago copia del usuario y lo guardo en registros del controlador con la fecha actual
        controller.getSignings().add(new User(user));

        /*Cambio el atributo "entering" del usuario en el controller
        para la próxima vez que ponga su código saber si le toca salir o entrar.*/
        if (user.isEntering()) user.setEntering(false);
        else user.setEntering(true);

        //Hago un Update del user en la bbdd.
        controller.updateUser(user);

    }

    private static void espera() {
        try {
            Thread.sleep(2500);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }


    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
