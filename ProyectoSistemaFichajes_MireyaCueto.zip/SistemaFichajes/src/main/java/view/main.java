package view;

import controller.Controller;
import models.User;

import java.util.Scanner;

public class main {

    /* CLASE PRIMERA USADA COMO BASE */

    //Constant Scanner (for console):
    public static final Scanner S = new Scanner(System.in);

    //MAIN:
    public static void main(String[] args) {
        Controller controller = new Controller();
        int code = 0;
        do {
            startApplication(code, controller);
        } while (true);
    }

    //Función que inicia la App:
    private static void startApplication(int code, Controller controller) {
        try {
            System.out.print("Por favor, inserta tu código: ");
            code = Integer.parseInt(S.nextLine());
            if (code > 1000 && code < 9999){
                //Recupero el usuario con ese código
                User user = controller.searchUserByCode(code);
                if (user!=null){
                    // Miro si esAdmin o trabajador:
                    if (user.isAdmin()) loginAdmin(controller);
                    else loginTrabajador(user, controller);
                } else System.out.println("El código no existe. Pruebe de nuevo.");
            } else System.out.println("El código debe ser de 4 cifras. Pruebe de nuevo.");
        } catch (Exception e){
            System.out.println("Valor incorrecto. Pruebe de nuevo.");
        }
    }

    //Acciones del Admin:
    private static void loginAdmin(Controller controller) {
        //Muestro toString de todos los registros del controlador
        if (!controller.getSignings().isEmpty()){
            for (User signing : controller.getSignings()){
                System.out.println(signing);
            }
        } else System.out.println("No hay registros aún.");
        //Doy opción de volver atrás para poner otro código
        System.out.print("Pulsa 'Enter' para continuar... ");
        S.nextLine();
    }

    //Acciones del Trabajador:
    private static void loginTrabajador(User user, Controller controller) {
        // Miro su atributo "entering" para hablarle.
        if (user.isEntering()) System.out.println("Bienvenid@");
        else System.out.println("Hasta la próxima.");

        //Hago una copia del usuario y lo guardo en registros de la bbdd con la fecha actual
        controller.insertSigning(user);

        //Hago copia del usuario y lo guardo en registros del controlador con la fecha actual
        controller.getSignings().add(new User(user));

        /*Cambio el atributo "entering" del usuario en el controller
        para la próxima vez que ponga su código saber si le toca salir o entrar.*/
        if (user.isEntering()) user.setEntering(false);
        else user.setEntering(true);

        //Hago un Update del user en la bbdd.
        controller.updateUser(user);
    }
}
